const Home = () => {
    return (       
        <main>
            <div className="welcome">
                <h1 className="greet">GREETINGS!</h1>      
            </div>
        </main> 
    )
}

export default Home
